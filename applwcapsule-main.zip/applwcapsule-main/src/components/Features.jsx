import React from 'react';
import { VolumeX, Shield, Brain, Thermometer, Clock, User, Sparkles } from 'lucide-react';
import './Features.css';

const featuresData = [
    {
        icon: <VolumeX size={32} />,
        title: "100% Soundproof",
        description: "Built using acoustic panel principles inspired by Framery Smart Pods."
    },
    {
        icon: <Shield size={32} />,
        title: "Privacy Guaranteed",
        description: "Your personal sanctuary. No interruptions, no distractions, just you and your work."
    },
    {
        icon: <Brain size={32} />,
        title: "Enhanced Concentration",
        description: "Focus support designed to increase student productivity by up to 40%."
    },
    {
        icon: <Thermometer size={32} />,
        title: "Climate Control",
        description: "Optimal temperature and air quality maintained with internal sensors and Dyson PureCool filtration principles."
    },
    {
        icon: <Clock size={32} />,
        title: "24/7 Availability",
        description: "Work on your schedule. The capsule is available whenever you need silence."
    },
    {
        icon: <User size={32} />,
        title: "Individual Spaces",
        description: "Each capsule is designed for solo use, ensuring you won't be disturbed by others."
    },
    {
        icon: <Sparkles size={32} />,
        title: "Automated Sanitization",
        description: "UV-light cleaner activates automatically between bookings for maximum safety and hygiene (similar to Uber Car Clean technology)."
    }
];

const Features = () => {
    return (
        <section className="section features-section">
            <div className="container">
                <div className="features-header">
                    <h2>Why Choose the Apple Capsule?</h2>
                    <p>Perfect for students, remote workers, researchers, or anyone who needs absolute silence to achieve their best work. Every detail is designed to eliminate distractions.</p>
                </div>

                <div className="features-grid">
                    {featuresData.map((feature, index) => (
                        <div className="feature-card" key={index}>
                            <div className="feature-icon">
                                {feature.icon}
                            </div>
                            <h3>{feature.title}</h3>
                            <p>{feature.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Features;
