import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MapPin, Sun, Moon, Map as MapIcon, User, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import './Header.css';

const Header = ({ theme, toggleTheme, city, setCity }) => {
  const navigate = useNavigate();
  const [showCityMenu, setShowCityMenu] = useState(false);
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleCitySelect = (selectedCity) => {
    setCity(selectedCity);
    setShowCityMenu(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="header">
      <div className="container header-content">
        <Link to="/" className="logo">
          <img src="/logo.png" alt="Apple Capsule Logo" className="logo-image" />
          <span>Apple Capsule</span>
        </Link>

        <button className="mobile-menu-toggle" onClick={toggleMobileMenu}>
          <span className={`hamburger ${isMobileMenuOpen ? 'open' : ''}`}></span>
        </button>

        <nav className={`nav ${isMobileMenuOpen ? 'mobile-open' : ''}`}>
          <div className="location-wrapper">
            <div
              className="location-selector"
              onClick={() => setShowCityMenu(!showCityMenu)}
            >
              <MapPin size={16} />
              <span>{city}</span>
              <span className="arrow">▼</span>
            </div>
            {showCityMenu && (
              <div className="city-menu">
                <div className="city-option" onClick={() => handleCitySelect('Almaty')}>Almaty</div>
                <div className="city-option" onClick={() => handleCitySelect('Astana')}>Astana</div>
              </div>
            )}
          </div>

          <button className="btn btn-outline find-domes-btn" onClick={() => navigate('/map')}>
            <MapIcon size={16} />
            <span>Find Capsules</span>
          </button>

          <button
            className="theme-toggle"
            onClick={toggleTheme}
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Sun size={20} /> : <Moon size={20} />}
          </button>

          <div className="user-menu">
            {user ? (
              <>
                <Link to="/my-bookings" className="user-name">Hi, {user.name}</Link>
                <button className="btn btn-ghost" onClick={logout} title="Log Out">
                  <LogOut size={20} />
                </button>
              </>
            ) : (
              <Link to="/login" className="btn btn-primary">
                <User size={16} style={{ marginRight: '8px' }} />
                Log In
              </Link>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
