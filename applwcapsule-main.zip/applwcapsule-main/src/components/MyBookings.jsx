import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Calendar, Clock, MapPin } from 'lucide-react';
import './MyBookings.css';

const MyBookings = () => {
    const { user, getBookings } = useAuth();
    const bookings = getBookings();

    if (!user) {
        return (
            <div className="container my-bookings-page">
                <h2>Please log in to view your bookings.</h2>
            </div>
        );
    }

    return (
        <div className="container my-bookings-page">
            <h2>My Bookings</h2>
            {bookings.length === 0 ? (
                <p>You have no active bookings.</p>
            ) : (
                <div className="bookings-list">
                    {bookings.map((booking) => (
                        <div key={booking.id} className="booking-item">
                            <div className="booking-header-item">
                                <span className="booking-status">{booking.status}</span>
                                <span className="booking-price">₸{booking.price}</span>
                            </div>
                            <div className="booking-details">
                                <div className="detail-row">
                                    <Calendar size={18} />
                                    <span>{booking.date}</span>
                                </div>
                                <div className="detail-row">
                                    <Clock size={18} />
                                    <span>{booking.timeSlot}</span>
                                </div>
                                <div className="detail-row">
                                    <MapPin size={18} />
                                    <span>{booking.location}</span>
                                </div>
                            </div>
                            <div className="booking-extras">
                                <small>Lighting: {booking.lighting}</small>
                                <small>Seat: {booking.seatHeight}</small>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default MyBookings;
