import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Hero.css';

const Hero = () => {
    const navigate = useNavigate();

    return (
        <section className="hero">
            <div className="container hero-content">
                <h1 className="hero-title">Apple Capsule: The Soundproof Sanctuary for Super-Focus</h1>
                <p className="hero-subtitle">
                    Designed to eliminate urban noise and concentration loss, which studies show can be up to 40% in inadequate environments.
                </p>
                <div className="hero-buttons">
                    <button
                        className="btn btn-primary cta-btn"
                        onClick={() => navigate('/map')}
                    >
                        Find Nearest Capsule
                    </button>
                    <button
                        className="btn btn-secondary cta-btn"
                        onClick={() => {
                            const bookingSection = document.getElementById('booking');
                            if (bookingSection) {
                                bookingSection.scrollIntoView({ behavior: 'smooth' });
                            }
                        }}
                    >
                        Book Your Session Now
                    </button>
                </div>
            </div>
        </section>
    );
};

export default Hero;
