import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Calendar, Clock, MapPin } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { locationsData } from '../data/locations';
import './Booking.css';

const timeSlots = [
    "09:00 AM", "11:00 AM", "01:00 PM",
    "03:00 PM", "05:00 PM", "07:00 PM"
];

const Booking = () => {
    const { user, addBooking } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();

    const [selectedSlot, setSelectedSlot] = useState(null);
    const [date, setDate] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [selectedLocation, setSelectedLocation] = useState('');
    const [lighting, setLighting] = useState('cool');
    const [seatHeight, setSeatHeight] = useState('auto');
    const [showSuccess, setShowSuccess] = useState(false);

    // Get all locations flat list
    const allLocations = [
        ...locationsData.Almaty.locations,
        ...locationsData.Astana.locations
    ];

    useEffect(() => {
        // Handle scroll and pre-fill from navigation state
        if (location.state) {
            if (location.state.scrollToBooking) {
                const element = document.getElementById('booking');
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                }
            }
            if (location.state.location) {
                setSelectedLocation(location.state.location);
            }
        }
    }, [location.state]);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!user) {
            alert('Please log in to book a session.');
            navigate('/login');
            return;
        }

        if (!selectedSlot || !date || !name || !email || !selectedLocation) {
            alert('Please fill in all required fields.');
            return;
        }

        const bookingDetails = {
            name,
            email,
            date,
            timeSlot: selectedSlot,
            location: selectedLocation,
            lighting,
            seatHeight,
            price: 1350
        };

        if (addBooking(bookingDetails)) {
            setShowSuccess(true);
            // Reset form
            setSelectedSlot(null);
            setDate('');
            setName('');
            setEmail('');
            setSelectedLocation('');
        }
    };

    if (showSuccess) {
        return (
            <section className="section booking-section" id="booking">
                <div className="container">
                    <div className="booking-card success-card">
                        <div className="success-content">
                            <h3>Booking Confirmed! 🎉</h3>
                            <p>Your session at Apple Dome has been successfully booked.</p>
                            <div className="booking-summary">
                                <p><strong>Location:</strong> {selectedLocation}</p>
                                <p><strong>Date:</strong> {date}</p>
                                <p><strong>Time:</strong> {selectedSlot}</p>
                                <p><strong>Price:</strong> ₸1,350</p>
                            </div>
                            <button
                                className="btn btn-primary"
                                onClick={() => setShowSuccess(false)}
                            >
                                Book Another Session
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        );
    }

    return (
        <section className="section booking-section" id="booking">
            <div className="container">
                <div className="booking-header">
                    <h2>Book Your Session</h2>
                    <p>Reserve your time in the Apple Dome and experience productivity like never before.</p>
                </div>

                <div className="booking-card">
                    <div className="booking-form-header">
                        <h3>Schedule Your Visit</h3>
                        <p>Choose your preferred date and time slot</p>
                    </div>

                    <form className="booking-form" onSubmit={handleSubmit}>
                        <div className="form-row">
                            <div className="form-group">
                                <label>Full Name</label>
                                <input
                                    type="text"
                                    placeholder="John Doe"
                                    className="form-input"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Email</label>
                                <input
                                    type="email"
                                    placeholder="john@example.com"
                                    className="form-input"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Select Location</label>
                            <div className="input-with-icon">
                                <MapPin size={18} className="input-icon" />
                                <select
                                    className="form-input"
                                    value={selectedLocation}
                                    onChange={(e) => setSelectedLocation(e.target.value)}
                                    required
                                >
                                    <option value="">Choose a location...</option>
                                    {allLocations.map(loc => (
                                        <option key={loc.id} value={loc.name}>
                                            {loc.name} ({loc.status})
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Select Date</label>
                            <div className="input-with-icon">
                                <Calendar size={18} className="input-icon" />
                                <input
                                    type="date"
                                    className="form-input"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Select Time Slot</label>
                            <div className="time-slots-grid">
                                {timeSlots.map((slot, index) => (
                                    <button
                                        key={index}
                                        type="button"
                                        className={`time-slot-btn ${selectedSlot === slot ? 'active' : ''}`}
                                        onClick={() => setSelectedSlot(slot)}
                                    >
                                        <Clock size={16} />
                                        {slot}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="customization-section">
                            <button
                                type="button"
                                className="customization-toggle"
                                onClick={() => document.getElementById('customization-options').classList.toggle('open')}
                            >
                                <span>Customize Your Pod Environment</span>
                                <span className="toggle-icon">▼</span>
                            </button>
                            <div id="customization-options" className="customization-options">
                                <div className="form-group">
                                    <label>Preferred Lighting Profile</label>
                                    <select
                                        className="form-input"
                                        value={lighting}
                                        onChange={(e) => setLighting(e.target.value)}
                                    >
                                        <option value="cool">Cool White (Focus)</option>
                                        <option value="warm">Warm Ambient (Relax)</option>
                                        <option value="natural">Natural Daylight</option>
                                    </select>
                                    <small className="form-hint">Based on Philips Hue models</small>
                                </div>
                                <div className="form-group">
                                    <label>Adjustable Seat Height</label>
                                    <select
                                        className="form-input"
                                        value={seatHeight}
                                        onChange={(e) => setSeatHeight(e.target.value)}
                                    >
                                        <option value="auto">Auto-set system</option>
                                        <option value="manual">Manual Adjustment</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <button type="submit" className="btn btn-primary submit-btn">
                            Confirm Booking (₸1,350)
                        </button>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default Booking;
