import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './MapSection.css';
import { locationsData } from '../data/locations';

// Fix for default marker icon
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom Capsule Icon
const capsuleIcon = (status) => new L.DivIcon({
  className: 'custom-capsule-icon',
  html: `<div style="background-color: ${status === 'Available' ? '#E60000' : '#888'}; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z"/><path d="M10 2c1 .5 2 2 2 5"/></svg>
         </div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 15],
  popupAnchor: [0, -15]
});

const MapSection = ({ city = 'Almaty' }) => {
  const navigate = useNavigate();
  const cityData = locationsData[city] || locationsData.Almaty;

  return (
    <section className="map-section-full">
      <div className="map-header">
        <h2>Capsule Locations in {city}</h2>
        <p>Find your nearest Apple Capsule workspace</p>
      </div>

      <div className="map-container-wrapper">
        <div className="locations-sidebar">
          <h3>All Locations</h3>
          <div className="status-legend">
            <div className="legend-item">
              <div className="status-dot available"></div>
              <span>Available</span>
            </div>
            <div className="legend-item">
              <div className="status-dot occupied"></div>
              <span>Occupied</span>
            </div>
          </div>
          <ul className="locations-list">
            {cityData.locations.map(loc => (
              <li key={loc.id} className="location-item">
                <div className={`location-dot ${loc.status.toLowerCase()}`}></div>
                <div>
                  <h4>{loc.name}</h4>
                  <p>{loc.address}</p>
                  <span className={`status-badge ${loc.status.toLowerCase()}`}>{loc.status}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="map-wrapper">
          <MapContainer
            center={cityData.center}
            zoom={12}
            scrollWheelZoom={true}
            style={{ height: '100%', width: '100%' }}
            key={city}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {cityData.locations.map(loc => (
              <Marker key={loc.id} position={loc.coords} icon={capsuleIcon(loc.status)}>
                <Popup>
                  <div className="map-popup-content">
                    <strong>{loc.name}</strong><br />
                    <span className="popup-address">{loc.address}</span><br />
                    <div className="popup-status" style={{ color: loc.status === 'Available' ? '#22c55e' : '#888' }}>
                      {loc.status}
                    </div>
                    <div className="popup-price">Starting from ₸1,350/hr</div>
                    {loc.status === 'Available' && (
                      <button
                        className="btn-popup-book"
                        onClick={() => {
                          navigate('/', { state: { scrollToBooking: true, location: loc.name } });
                        }}
                      >
                        Book Now
                      </button>
                    )}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      </div>
    </section>
  );
};

export default MapSection;
