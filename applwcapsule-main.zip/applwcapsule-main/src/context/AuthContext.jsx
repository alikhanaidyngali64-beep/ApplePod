import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        // Check local storage for existing session
        const storedUser = localStorage.getItem('appleDomeUser');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
    }, []);

    const login = (email, password) => {
        // Mock login logic
        if (email && password) {
            const mockUser = {
                id: '1',
                name: email.split('@')[0],
                email: email,
            };
            setUser(mockUser);
            localStorage.setItem('appleDomeUser', JSON.stringify(mockUser));
            return true;
        }
        return false;
    };

    const signup = (name, email, password) => {
        // Mock signup logic
        if (name && email && password) {
            const mockUser = {
                id: '1',
                name: name,
                email: email,
            };
            setUser(mockUser);
            localStorage.setItem('appleDomeUser', JSON.stringify(mockUser));
            return true;
        }
        return false;
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('appleDomeUser');
    };

    const addBooking = (bookingDetails) => {
        if (!user) return false;

        const newBooking = {
            id: Date.now().toString(),
            userId: user.id,
            status: 'Confirmed',
            createdAt: new Date().toISOString(),
            ...bookingDetails
        };

        const existingBookings = JSON.parse(localStorage.getItem('appleDomeBookings') || '[]');
        const updatedBookings = [...existingBookings, newBooking];
        localStorage.setItem('appleDomeBookings', JSON.stringify(updatedBookings));

        return true;
    };

    const getBookings = () => {
        if (!user) return [];
        const allBookings = JSON.parse(localStorage.getItem('appleDomeBookings') || '[]');
        return allBookings.filter(booking => booking.userId === user.id);
    };

    return (
        <AuthContext.Provider value={{ user, login, signup, logout, addBooking, getBookings }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
