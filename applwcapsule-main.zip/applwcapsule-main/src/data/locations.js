export const locationsData = {
    Almaty: {
        center: [43.2220, 76.9150],
        locations: [
            { id: 1, name: "Mega Almaty", coords: [43.2005, 76.8922], address: "Rozybakiev St 247A", status: "Available" },
            { id: 2, name: "Dostyk Plaza", coords: [43.2335, 76.9568], address: "Samal-2, 111", status: "Available" },
            { id: 3, name: "Esentai Mall", coords: [43.2188, 76.9286], address: "Al-Farabi Ave 77/8", status: "Occupied" },
            { id: 4, name: "ADK Almaty", coords: [43.2393, 76.8732], address: "Satpayev St 90", status: "Available" },
            { id: 5, name: "Atakent Mall", coords: [43.2245, 76.9085], address: "Timiryazev St 42", status: "Available" },
        ]
    },
    Astana: {
        center: [51.1694, 71.4491],
        locations: [
            { id: 6, name: "Khan Shatyr", coords: [51.1327, 71.4043], address: "Turan Ave 37", status: "Available" },
            { id: 7, name: "Mega Silk Way", coords: [51.1288, 71.4178], address: "Kabanbay Batyr Ave 62", status: "Available" },
            { id: 8, name: "Keruen Mall", coords: [51.1816, 71.4230], address: "Saraishyk St 7", status: "Occupied" },
            { id: 9, name: "Sary Arka", coords: [51.1590, 71.4703], address: "Kurmangazy St 4", status: "Available" },
        ]
    }
};
