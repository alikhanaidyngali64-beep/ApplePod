import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Booking from './components/Booking';
import MapSection from './components/MapSection';
import Footer from './components/Footer';
import Login from './components/Login';
import Signup from './components/Signup';
import MyBookings from './components/MyBookings';
import './App.css';

function App() {
  const [theme, setTheme] = useState('light');
  const [city, setCity] = useState('Almaty');

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Header
            theme={theme}
            toggleTheme={toggleTheme}
            city={city}
            setCity={setCity}
          />
          <main>
            <Routes>
              <Route path="/" element={
                <>
                  <Hero />
                  <Features />
                  <Booking />
                </>
              } />
              <Route path="/map" element={<MapSection city={city} />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/my-bookings" element={<MyBookings />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
